#/bin/bash

echo "Creating gitlab and cermanager base directory..."
mkdir -p /opt/certmgr/certs
mkdir -p /opt/gitlab/{config,data,logs}

echo "Installing docker engine..."
apt-get update -y
apt-get remove docker docker-engine docker.io containerd runc -y
apt-get update -y
apt-get install  -y \
    ca-certificates \
    curl \
    gnupg \
    lsb-release
apt-get update -y
mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

apt-get update -y
apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

echo "Deploying gitlab..."
export GITLAB_HOME=/opt/gitlab

docker compose -f gitlab-compose.yml up -d

echo "Happy CI/CD!"
