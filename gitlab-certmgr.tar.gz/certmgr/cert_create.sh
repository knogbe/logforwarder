#/bin/bash
mkdir /etc/gitlab/ssl/
mkdir /etc/gitlab/trusted-certs
echo "Generating Root Certificate key..."
openssl genrsa -aes256 -passout pass:${CA_KEY_PASSWORD} -out  /opt/certmgr/certs/${CA_CNAME}.key 4096
echo "Generating Root Certificate for the key..."
openssl req -x509 -new -nodes -key /opt/certmgr/certs/${CA_CNAME}.key \
  -passin pass:${CA_KEY_PASSWORD} \
  -sha256 -days 3650 -out /opt/certmgr/certs/${CA_CNAME}.crt \
  -subj "/C=US/ST=Georgia/L=ATlanta/O=Nexaria/CN=${CA_CNAME}"
echo "Generating application gitlab certificate request and key..."
openssl req -new -nodes -out /opt/certmgr/certs/${APP_CNAME}.csr \
  -newkey rsa:4096 \
  -keyout /etc/gitlab/ssl/${APP_CNAME}.key \
  -subj "/C=US/ST=Georgia/L=ATlanta/O=Nexaria/CN=${APP_CNAME}"
cat > /opt/certmgr/certs/${APP_CNAME}.ext << EOF
  authorityKeyIdentifier=keyid,issuer
  basicConstraints=CA:FALSE
  keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
  subjectAltName = @alt_names
  [alt_names]
  DNS.1 = ${APP_CNAME}
EOF
echo "Signing the certificate"
openssl x509 -req -in /opt/certmgr/certs/${APP_CNAME}.csr \
  -CA /opt/certmgr/certs/${CA_CNAME}.crt \
  -CAkey /opt/certmgr/certs/${CA_CNAME}.key \
  -passin pass:${CA_KEY_PASSWORD} \
  -CAcreateserial -out /etc/gitlab/ssl/${APP_CNAME}.crt \
  -days 1826 \
  -sha256 \
  -extfile /opt/certmgr/certs/${APP_CNAME}.ext
cp /opt/certmgr/certs/${CA_CNAME}.crt /etc/gitlab/trusted-certs/


