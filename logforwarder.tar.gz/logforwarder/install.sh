#!/bin/bash

echo "Creating logforwarder application dir ..."
mkdir /opt/logforwarder
mkdir /opt/logforwarder/etc
mkdir /opt/logforwarder/bin
mkdir /opt/logforwarder/logs
echo "Creating logforwarder application dir completed."

echo "Installing logforwarder binary..."
cp ./logforwarder /opt/logforwarder/bin/

if [[ -f /opt/logforwarder/bin/logforwarder ]]; then
    echo "Installing logforwarder binary successfully installed."
fi
echo "Installing logforwarder configuration..."
cp ./forwarder.conf /opt/logforwarder/etc/

if [[ -f /opt/logforwarder/etc/forwarder.conf ]]; then
    echo "Installing logforwarder configuration successfully installed."
fi

echo "Initializing log stagging file and log record tracking file..."
touch /opt/logforwarder/logs/dump.log
touch /opt/logforwarder/etc/log_record.db

echo "Installing logforwarder service..."
cp logforwarder.service  /etc/systemd/system/
if [[ -f /etc/systemd/system/logforwarder.service ]]; then
    echo "logforwarder service successfully installed."
fi
echo "Enabling logforwarder service."
systemctl daemon-reload
systemctl enable logforwarder
echo "logforwarder installation completed. Please configure target syslog server and port"
echo "Configuration file locate at /opt/logforwarder/etc/forwarder.conf"
echo "Start service <systemctl start logforwarder>"

