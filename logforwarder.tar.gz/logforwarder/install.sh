#!/bin/bash

BASE_DIR=/app

echo "Installing python3 package"
pip3 install -r requirements.txt

echo "Creating logforwarder application dir ..."
mkdir ${BASE_DIR}/logforwarder
mkdir ${BASE_DIR}/logforwarder/etc
mkdir ${BASE_DIR}/logforwarder/bin
mkdir ${BASE_DIR}/logforwarder/logs
echo "Creating logforwarder application dir completed."

echo "Installing logforwarder binary..."
cp ./logforwarder ${BASE_DIR}/logforwarder/bin/

if [[ -f ${BASE_DIR}/logforwarder/bin/logforwarder ]]; then
    echo "Installing logforwarder binary successfully installed."
fi
echo "Installing logforwarder configuration..."
cp ./forwarder.conf ${BASE_DIR}/logforwarder/etc/

if [[ -f ${BASE_DIR}/logforwarder/etc/forwarder.conf ]]; then
    echo "Installing logforwarder configuration successfully installed."
fi

echo "Initializing log stagging file and log record tracking file..."
touch ${BASE_DIR}/logforwarder/logs/dump.log
touch ${BASE_DIR}/logforwarder/etc/log_record.db

echo "Installing logforwarder service..."
cp logforwarder.service  /etc/systemd/system/
if [[ -f /etc/systemd/system/logforwarder.service ]]; then
    echo "logforwarder service successfully installed."
fi
echo "Enabling logforwarder service."
systemctl daemon-reload
systemctl enable logforwarder
echo "logforwarder installation completed. Please configure target syslog server and port"
echo "Configuration file locate at ${BASE_DIR}/logforwarder/etc/forwarder.conf"
echo "Start service <systemctl start logforwarder>"

