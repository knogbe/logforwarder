Installing log forwarder app

Step 1
untar logforwarder.tar.gz
  #tar -zxvf logforwarder.tar.gz

Step 2
Run the install script
  #cd logforwarder
  #./install.sh

Step 3
Edit the config file if needed 
  #vi /app/logforwarder/etc/forwarder.conf

Step 4
Start the application
  #systemctl start logforwarder

When using rabbitmq input, make sure you configure in rabbitmq.conf
# 30 minutes in milliseconds
consumer_timeout = 1800000
# one hour in milliseconds
consumer_timeout = 3600000
